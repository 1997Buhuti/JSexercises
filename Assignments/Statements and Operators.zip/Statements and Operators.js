/*
Author: D.P.B Manakal
DateCreated:28/03/2021
*/

// Assignment 1

const mortals=['Putin','Socrates','Aristotal'];

for(let i=0;i<mortals.length;i++){

    if(mortals[i]==='Socrates'){

        console.log(i);
        console.log("Socrates is a mortal");
    }
}

//Assignment 2

let cake = "vanilla";

if (cake !== "chocolate") {
  console.log("This cake is vanilla.");
} else {
  console.log("This cake is chocolate.");
}
